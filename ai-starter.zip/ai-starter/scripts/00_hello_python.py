"""
M0 — Hello Python
Demonstrates: variables, functions, dataclass, TypedDict, env vars

Run:
    source .venv/bin/activate
    pip install python-dotenv
    python scripts/00_hello_python.py
"""

import os
from dataclasses import dataclass
from typing import TypedDict
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


# --- 1. Basic variables and f-string ---
name: str = "System Architect"
language: str = "Python"
print(f"Hello, {name}. Welcome to {language}.")


# --- 2. Function with type hints ---
def calculate_risk_score(exposure: float, probability: float) -> float:
    """Simple expected loss formula — maps to EL = EAD x PD in credit risk."""
    return round(exposure * probability, 4)


score = calculate_risk_score(exposure=1_000_000.0, probability=0.03)
print(f"Expected Loss: EUR {score:,.2f}")


# --- 3. Dataclass (Java Record equivalent) ---
@dataclass
class Transaction:
    id: str
    amount: float
    currency: str
    flagged: bool = False


tx = Transaction(id="TX-9921", amount=2_500_000.0, currency="EUR")
print(f"Transaction: {tx}")


# --- 4. TypedDict (LangGraph state preview) ---
class WorkflowState(TypedDict):
    document_text: str
    risk_score: float
    approved: bool


state: WorkflowState = {
    "document_text": "Client Q1 financials: revenue EUR 50M, debt EUR 120M",
    "risk_score": 0.0,
    "approved": False,
}
print(f"Initial state: {state}")


# --- 5. Environment variables ---
email = os.getenv("DBLLM_EMAIL", "NOT SET — add to .env file")
print(f"DB LLM will use email: {email}")
