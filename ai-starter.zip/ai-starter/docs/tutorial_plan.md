# From Java to LLMs: A System Architect's Guide to Building Enterprise AI with LangGraph

> **Audience** — System Architects & Engineers proficient in Java · Spring Boot · GCP  
> **Goal** — Master LLM-based application design: from raw API calls to production-grade multi-agent systems  
> **Style** — Concepts & architecture first · Code as "try it out" companions · Every idea bridged to Java/Spring

---

## Why This Tutorial Exists

Large Language Models are no longer research curiosities — they are becoming first-class components in enterprise software. But most learning material is written *for data scientists*, not for engineers who think in terms of distributed systems, service contracts, and production reliability.

This curriculum is different. It is written **for engineers who already know how to build complex systems** and need to understand:

1. How LLMs work as an API (you already know REST — this is just REST with intelligence)
2. Why orchestration frameworks like LangChain and LangGraph exist and what problems they solve
3. What *agentic design patterns* look like — and how they map to patterns you already know
4. How to design, build, and run an enterprise-grade LLM application on GCP

---

## The Learning Arc

```
Raw LLM API  →  LangChain  →  LangGraph  →  Agentic Patterns  →  MCP  →  Production GCP
    M0–M2           M3–M5         M6–M7            M8               M9       M10–M11
                                                              └──────── Capstone ──────────┘
```

Each phase answers a natural question that emerges from the previous one:

- *"I can call the LLM API directly — why do I need LangChain?"*
- *"I have LangChain agents — why do I need LangGraph?"*
- *"I have a LangGraph app — how do I design it like an architect?"*
- *"My design is solid — how do I make it production-ready on GCP?"*

---

## Java ↔ LLM Framework Analogy Map

> Use this as your mental translation layer throughout the curriculum.

| Java / Spring Concept | LLM / LangGraph Equivalent |
|---|---|
| Maven / Gradle module scope | Python `venv` (virtual environment) |
| `pom.xml` dependency | `pip install` / `requirements.txt` |
| POJO / Java Record | `TypedDict` / Pydantic model |
| `@Service` method | LangChain Tool / LangGraph node function |
| `Stream.map().filter().collect()` | LCEL: `prompt \| model \| parser` |
| Spring `@Component` with I/O contract | LangGraph `node` |
| Spring State Machine / Temporal Workflow | LangGraph `StateGraph` with typed state |
| Spring Data Repository | RAG Retriever (semantic query over vector store) |
| Orchestrator–Worker (Saga pattern) | Plan-and-Execute agentic pattern |
| `CompletableFuture.allOf()` | LangGraph parallel fan-out branches |
| Spring Boot Actuator + Zipkin | LangSmith (tracing, cost, debugging) |
| Async callback / workflow wait state | Human-in-the-Loop (HITL) node |
| `application.properties` | Prompt Store (externalised, versioned prompts) |
| OpenAPI / REST contract for microservices | MCP (Model Context Protocol) for agent tools |

---

## Curriculum Overview

### Phase 1 — Foundation `M0 · M1 · M2`
*Get comfortable with Python and speak directly to an LLM*

### Phase 2 — LangChain `M3 · M4 · M5`
*Understand why orchestration frameworks exist and master RAG*

### Phase 3 — LangGraph `M6 · M7`
*Build stateful, conditional, multi-step agent workflows*

### Phase 4 — Enterprise `M8 · M9 · M10 · M11`
*Agentic design patterns, MCP servers, memory, and GCP production*

### Capstone
*End-to-end Intelligent Credit Risk Analysis Agent*

---

## Module Details

---

### M0 — Python Orientation for Java Engineers

> *"Python is Java without the ceremony. Your instincts are right — just unlearn the braces."*

**What you will learn**
- Python vs Java: syntax mapping — classes, interfaces, generics, lambdas
- Virtual environments: why they exist and how they compare to Maven module scope
- Type hints: Python's equivalent of Java's type system (familiar, optional, but recommended)
- Project structure, running `.py` scripts, using a REPL for exploration
- `pip`, `requirements.txt`, and `pyproject.toml`

**Key concepts introduced**
- `dataclass` ≈ Java Record
- `Protocol` ≈ Java Interface
- `dict` and `TypedDict` ≈ POJO (the workhorse of LLM frameworks)

**Try it out**
```
# Setup
python3 -m venv .venv
source .venv/bin/activate
pip install openai
python scripts/00_hello_python.py
```

---

### M1 — Raw LLM Interactions

> *"Before any framework, understand what you are actually calling. It is just an HTTP endpoint."*

**What you will learn**
- What an LLM API is under the hood: a REST `POST` with a JSON body and a JSON response
- `system` / `user` / `assistant` message roles and why they exist
- Key parameters: `temperature`, `max_tokens`, `stop`, `top_p` — what each controls
- Structured JSON output mode: making the LLM return machine-readable data (critical for integration)
- How the DB internal wrapper compares to the standard SDK (a 2-line swap)

**Progression in this module**
```
curl (raw HTTP)  →  Python requests  →  openai SDK  →  structured JSON output
```

**Try it out**
```
python scripts/01_raw_llm.py
```

> `# TODO-DB:` Every script contains a clearly marked block showing where the DB internal LLM client replaces the standard one — same interface, different base URL and auth header.

---

### M2 — Prompt Engineering

> *"The prompt is the source code of an LLM call. Engineer it as rigorously as you would any interface contract."*

**What you will learn**
- **Zero-shot**: give the task, no examples — when it works and when it fails
- **Few-shot**: provide input/output examples — the LLM learns the pattern in-context
- **Chain-of-Thought (CoT)**: instruct the model to reason step-by-step before answering
- Prompt templates: from f-strings to reusable, parameterised templates (before LangChain)
- Output parsing: regex → JSON → Pydantic models
- Prompt hygiene: avoiding injection vulnerabilities (OWASP Top 10 for LLMs)

**Banking examples used**
- Classify a payment description as normal / suspicious / escalate
- Extract structured fields from a trade confirmation message
- Summarise a regulatory document in a given output schema

**Try it out**
```
python scripts/02_prompt_engineering.py
```

---

### M3 — Why LangChain? Abstractions, LCEL, Memory

> *"Raw API calls scale badly. LangChain is the Spring Boot of LLM development — it gives you the plumbing."*

**The problem it solves**
At scale, raw API calls produce: boilerplate explosion, no composability, manual retry logic, no conversation memory, and duplicated prompt management. LangChain solves all of these.

**What you will learn**
- The three core LangChain bricks: `ChatModel` · `PromptTemplate` · `OutputParser`
- **LCEL** (LangChain Expression Language): `prompt | model | parser`
  - Java analogy: `Stream.map().filter().collect()` — lazy, composable pipeline
- Conversation memory: `ConversationBufferMemory` vs `ConversationSummaryMemory`
- Prompt versioning and the prompt store pattern — externalise prompts from code (compliance-friendly)

**Try it out**
```
python scripts/03_langchain_basics.py
```

---

### M4 — Tools & Agents in LangChain

> *"Give the LLM the ability to call your services. It decides when and how — you define what."*

**What you will learn**
- The **Tool** abstraction: an LLM-callable function with a name, description, and schema
  - Java analogy: a Spring `@Service` method annotated for LLM discovery
- **ReAct agent loop**: Reason → Act → Observe → Repeat
- Creating custom tools; using built-in tools
- Where vanilla LangChain agents hit their limits:
  - No durable state across steps
  - No conditional branching
  - No loops without infinite recursion risk
  - No human approval gates

> This module ends with a deliberate cliffhanger — the limitations set up the motivation for LangGraph.

**Try it out**
```
python scripts/04_tools_agent.py
```

---

### M5 — RAG: Retrieval-Augmented Generation

> *"LLMs know everything about the world but nothing about your bank. RAG fixes that."*

**What you will learn**
- Why LLMs hallucinate on private/proprietary data — and why fine-tuning is not always the answer
- **Embeddings** explained intuitively: a document's meaning encoded as a `float[]` vector. Similar meaning = vectors close in cosine distance. No keyword matching needed.
- **Vector databases**: ChromaDB (local dev) · Vertex AI Matching Engine · AlloyDB with pgvector (GCP native)
- The full RAG pipeline:

```
Document Loader  →  Text Splitter  →  Embedding Model  →  Vector Store
                                                               ↓
User Query  →  Embed Query  →  Semantic Search  →  Retrieve Top-K  →  Augment Prompt  →  LLM  →  Answer
```

- Java analogy: the RAG retriever ≈ a `Spring Data` repository, but queries by *meaning* rather than SQL

**Banking example used**
- Ingest a Basel III regulatory PDF, ask compliance questions — grounded, cited answers

**Try it out**
```
python scripts/05_rag_pipeline.py
```

---

### M6 — Why LangGraph? StateGraph, Nodes, Edges

> *"LangChain gives you pipes. LangGraph gives you a workflow engine. Think Spring State Machine meets Temporal."*

**The problem it solves**
Complex enterprise tasks are not linear chains — they are **graphs**: conditional branches, loops, parallel steps, error recovery, and human approval gates. LangGraph models this explicitly.

**What you will learn**
- **StateGraph**: a graph where every node reads from and writes to a shared, typed state object
- **Typed State**: a `TypedDict` that is the single source of truth — ≈ a Java Record passed through a workflow
- **Nodes**: pure functions — receive state, return state delta. ≈ Spring `@Component` with I/O contract
- **Edges**: deterministic transitions between nodes
- **Conditional edges**: routing based on state values — ≈ a switch-case on workflow status
- Visualising the graph as an architecture diagram (key artifact for architects)

**Try it out**
```
python scripts/06_langgraph_intro.py   # 3-node graph with conditional routing
```

---

### M7 — Advanced LangGraph

> *"Now add the enterprise requirements: approvals, parallelism, persistence, and streaming."*

**What you will learn**
- **Human-in-the-Loop (HITL)**: pause the graph at a node, await external approval, resume — mandatory pattern for banking decisions
- **Parallel branches / fan-out**: run multiple agents simultaneously, merge results
  - Java analogy: `CompletableFuture.allOf()` — but with typed state merging
- **Subgraphs**: compose large agents from smaller, independently testable graphs
- **Checkpointing & persistence**: `SqliteSaver` (dev) → `PostgresSaver` (prod) — durable state across sessions, resumable after failure
- **Streaming**: emit tokens and intermediate node outputs in real time — for responsive UIs and monitoring

**Try it out**
```
python scripts/07_langgraph_advanced.py
```

---

### M8 — Agentic Design Patterns

> *"Agents have their own Gang of Four. Name the patterns, and you can design and communicate architectures clearly."*

**What you will learn**

| Pattern | Description | Java Analogy | Banking Use Case |
|---|---|---|---|
| **ReAct** | Reason → Act → Observe loop | Event-driven state machine | Research agent for regulatory lookup |
| **Plan & Execute** | Planner decomposes task; executors run subtasks | Orchestrator-Worker / Saga | Multi-document credit analysis |
| **Reflection / Self-Critique** | Agent reviews its own output before returning | Validator interceptor chain | Compliance check before report generation |
| **Multi-Agent Supervisor** | Orchestrator routes to specialist sub-agents | Spring Integration router | Supervisor over Analyst + Compliance + Risk agents |
| **Parallelisation** | Fan-out to independent agents, merge results | `CompletableFuture.allOf()` | Simultaneous financial + news + sentiment analysis |
| **Human-in-the-Loop** | Pause, await approval, resume | Async callback / workflow wait state | Senior analyst approval before credit decision |
| **Tool-Augmented** | Agent selects tools dynamically at runtime | Dynamic dispatch / Strategy pattern | Agent choosing between DB query, web search, calculator |

**Anti-patterns** — when NOT to use agents:
- Simple deterministic pipelines (use a plain chain)
- Latency-critical paths (agent loops add round-trips)
- When auditability requires exact reproducibility (stochastic agents complicate this)

**Try it out**
```
python scripts/08_agentic_patterns.py   # each pattern as a runnable example
```

---

### M9 — MCP Servers: The Microservice Contract for Agent Tools

> *"MCP is to agent tools what OpenAPI is to REST microservices. Your teams own their tools independently."*

**What you will learn**
- **Model Context Protocol (MCP)**: an open standard for how LLM agents discover and invoke external tools
- Why MCP matters for enterprise architecture:
  - Decouples agent logic from tool implementation
  - Teams own and deploy their MCP servers independently
  - Any compliant agent (LangGraph, Claude, etc.) can consume any MCP server
  - Standard auth, schema, and discovery — no more hardcoded tool wiring
- Build a simple MCP tool server (e.g. an internal credit data lookup service)
- Connect it to a LangGraph agent as an external tool
- GCP hosting: Cloud Run as the MCP server host
- Security: OAuth2 / service account auth, input validation, rate limiting

**Try it out**
```
python scripts/09_mcp_server.py          # the tool server
python scripts/09_mcp_client_agent.py   # LangGraph agent consuming it
```

---

### M10 — Agent Memory & Data Sharing

> *"A stateless agent is like a Spring service with no database. Useful, but limited. Memory makes agents genuinely intelligent over time."*

**What you will learn**

| Memory Type | Storage | Scope | Use Case |
|---|---|---|---|
| **In-state (short-term)** | LangGraph `TypedDict` state | One graph run | Pass context between nodes in a workflow |
| **Conversation memory** | Buffer or summary in state | One session | Multi-turn user interaction |
| **Semantic memory (long-term)** | Vector store | Cross-session | "Remember what we decided about client X last month" |
| **Episodic / audit store** | Postgres / BigQuery | Permanent | Regulatory audit trail of every agent decision |

- Passing structured data between specialist agents via typed state fields
- Vector store as long-term semantic memory: store and retrieve past decisions by meaning
- Writing agent outputs to Postgres or BigQuery for audit — **non-negotiable in a regulated bank**
- **pgvector on AlloyDB** (GCP-native): one database for both relational and vector data

**Try it out**
```
python scripts/10_agent_memory.py
```

---

### M11 — Production on GCP

> *"An agent that only runs on your laptop is a demo. This module makes it a product."*

**What you will learn**

**Wrapping as a service**
- Expose the LangGraph workflow as a FastAPI endpoint — ≈ Spring Boot REST controller
- Request/response schemas with Pydantic — ≈ Java DTOs
- Async streaming endpoints for real-time token output

**Deployment**
- Containerise with Docker (minimal, secure image)
- Deploy to **Cloud Run** — serverless, auto-scaling, GCP-native
- `cloudbuild.yaml` for CI/CD pipeline

**Observability with LangSmith**
- Trace every LLM call, tool invocation, and node transition
- Cost tracking per workflow run
- Debug failing runs by replaying the exact state at any node
- ≈ Spring Boot Actuator + Zipkin/Jaeger for LLM workflows

**Prompt Store**
- Externalise prompts from code into a versioned store
- Compliance teams can review/approve prompt changes independently of code deployments

**Security (OWASP LLM Top 10)**
- Prompt injection defence: input sanitisation, system prompt hardening
- PII detection and scrubbing before sending to external LLM APIs
- IAM: service account scoping, least-privilege access to LLM endpoints
- Output validation: never trust LLM-generated content as safe input to downstream systems

**Scaling**
- Stateless graphs → horizontal scale with Cloud Run concurrency
- Stateful graphs (with checkpointing) → sticky session or external state store pattern

**Try it out**
```
python scripts/11_fastapi_wrapper.py
docker build -t credit-agent .
gcloud run deploy credit-agent --source .
```

---

## Capstone — Intelligent Credit Risk Analysis Agent

> *A realistic, end-to-end system that ties together every module in the curriculum.*

### Domain

A bank's credit analyst team receives client dossiers containing financial statements, news articles, and internal ratings history. The current process is manual, time-consuming, and inconsistent. The goal is an **intelligent agent system** that processes these dossiers, performs multi-dimensional analysis, surfaces a risk recommendation, and routes to a human analyst for final sign-off — before generating a structured credit report.

### Architecture

```
                     ┌──────────────────────────────────────┐
                     │         Document Ingestor             │
                     │  (PDF loader, chunker, vector store)  │
                     └──────────────┬───────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    │          [parallel]            │
          ┌─────────▼──────────┐     ┌──────────────▼──────────────┐
          │ Financial Analyst  │     │  News & Sentiment Analyst    │
          │ Agent              │     │  Agent                       │
          │ (RAG over filings) │     │  (RAG over news corpus)      │
          └─────────┬──────────┘     └──────────────┬──────────────┘
                    └───────────────┬───────────────┘
                                    │
                     ┌──────────────▼───────────────────────┐
                     │       Compliance Checker              │
                     │  (RAG over regulatory KB: Basel III,  │
                     │   internal credit policy)             │
                     └──────────────┬───────────────────────┘
                                    │
                     ┌──────────────▼───────────────────────┐
                     │         Risk Scorer                   │
                     │  (aggregates signals → score + rationale) │
                     └──────────────┬───────────────────────┘
                                    │
                     ┌──────────────▼───────────────────────┐
                     │     Human Approval Gate (HITL)        │
                     │  Senior analyst reviews, approves     │
                     │  or sends back with comments          │
                     └──────────────┬───────────────────────┘
                                    │
                     ┌──────────────▼───────────────────────┐
                     │       Report Generator                │
                     │  (structured JSON + narrative PDF)    │
                     └──────────────┬───────────────────────┘
                                    │
                     ┌──────────────▼───────────────────────┐
                     │       Audit Store (BigQuery)          │
                     │  Full decision trail, inputs, scores  │
                     └──────────────────────────────────────┘
```

### What Each Module Contributes

| Module | Contribution to Capstone |
|---|---|
| M1–M2 | LLM calls and prompt templates inside each agent node |
| M3 | LCEL chains within analyst agents |
| M5 | RAG over financial filings, news, and regulatory documents |
| M6 | LangGraph state and node/edge wiring |
| M7 | Parallel branches, HITL gate, checkpointing for resumability |
| M8 | Supervisor pattern orchestrating specialist agents |
| M9 | MCP server for internal credit DB lookup tool |
| M10 | Audit trail to BigQuery, long-term semantic memory |
| M11 | FastAPI wrapper, Cloud Run deployment, LangSmith tracing |

### Success Criteria

- [ ] Agent processes a multi-document dossier end-to-end without manual intervention
- [ ] RAG responses are grounded and cited (no hallucination on policy questions)
- [ ] Parallel analyst branches complete and merge correctly into shared state
- [ ] HITL gate pauses graph, accepts analyst input via API, resumes correctly
- [ ] Every agent decision is written to the audit store with full lineage
- [ ] Service deployed to Cloud Run, observable in LangSmith
- [ ] Prompt injection inputs are rejected at the API boundary

---

## How to Navigate This Tutorial

```
Start here           Deep dive on demand         Your pace
    │                        │                       │
    ▼                        ▼                       ▼
Open M0 → M1 → M2    Ask "go deeper on M5 RAG"   Skip ahead,
                      Ask "show me the Spring      come back,
                      Boot equivalent"             branch freely
                      Ask "draw the architecture"
```

**In each session you can ask for:**
- A deeper code walkthrough of any `try it out` script
- An architecture diagram for any concept
- A comparison with the Spring Boot / Java equivalent
- A preview of how this module feeds into the capstone
- A challenge exercise to test your understanding

---

*Curriculum version 1.0 · June 2026*  
*Designed for Deutsche Bank Technology — System Architecture Guild*
