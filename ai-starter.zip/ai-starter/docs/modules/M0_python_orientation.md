# Module 0 — Python Orientation for Java Engineers

> **Phase:** Foundation  
> **Prerequisite:** None — this is the starting point  
> **Goal:** Get productive in Python fast by mapping everything you already know in Java to its Python equivalent

---

## 0.1 — Why Python for LLM Development?

Before writing a single line, it is worth asking: *why Python?*

The entire LLM ecosystem — LangChain, LangGraph, HuggingFace, vector databases, embedding libraries — is written in and for Python. Not because Python is superior to Java in general, but because the data science and ML communities adopted it first, and the tooling followed.

As a Java/Spring engineer, you are not starting from zero. You are translating. Your instincts about abstraction, contracts, separation of concerns, and production readiness are exactly right — the syntax is just different.

> **Mindset shift:** Python is not a scripting language you tolerate. Treat it the same way you would treat a new JVM language like Kotlin — same rigour, different idioms.

---

## 0.2 — Setting Up Your Environment

### The Two Approaches: `pip` (standard) vs `uv` (recommended in your org)

Python has two mainstream ways to manage dependencies and environments. We cover both — `pip` is the universal baseline, `uv` is what you should use in practice.

---

### Option A — pip + venv (standard, always available)

In Java, Maven or Gradle isolate dependencies per project via `pom.xml` or `build.gradle`. In Python, a **virtual environment** (`venv`) does the same — it creates an isolated Python installation per project so dependencies do not bleed across projects.

```bash
# Create a virtual environment (do this once per project)
python3 -m venv .venv

# Activate it (must do this every new terminal session)
source .venv/bin/activate          # macOS / Linux
.venv\Scripts\activate             # Windows

# Your prompt will change to show (.venv) — you are now inside the sandbox
```

```bash
# Install a single package
pip install openai

# Install from a requirements file (equivalent of pom.xml dependencies)
pip install -r requirements.txt

# Save current environment's packages (equivalent of locking versions)
pip freeze > requirements.txt
```

---

### Option B — uv (recommended: 10–100× faster, used org-wide)

**`uv`** is a modern Python package and project manager written in Rust. Think of it as the **Gradle Build Tool equivalent for Python** — it replaces `pip`, `venv`, `pip-tools`, and even `pyenv` (Python version management) with a single, fast binary.

> **Why uv?** `pip install` on a fresh project with 10 packages can take 30–60 seconds. `uv` does the same in under 2 seconds. It also produces a lockfile (`uv.lock`) for reproducible builds — critical for enterprise CI/CD pipelines.

#### Install uv

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Or via pip (bootstrap)
pip install uv

# Verify
uv --version
```

#### Starting a new project with uv

```bash
# Initialise a new project (creates pyproject.toml — ≈ pom.xml)
uv init ai-starter
cd ai-starter

# uv automatically creates and manages the virtual environment
# No manual 'source .venv/bin/activate' needed when using 'uv run'
```

#### Dependency management with uv

```bash
# Add a dependency (≈ mvn dependency:add or gradle implementation)
uv add openai
uv add python-dotenv
uv add langchain langgraph

# Add a dev-only dependency (≈ Maven test scope)
uv add --dev pytest ruff

# Remove a dependency
uv remove somepackage

# Sync all dependencies from lockfile (≈ mvn install / gradle build)
uv sync

# Upgrade all packages
uv sync --upgrade
```

#### Running scripts with uv

```bash
# Run a script inside the managed environment — no manual activation needed
uv run python scripts/00_hello_python.py

# Or activate manually if you prefer
source .venv/bin/activate
python scripts/00_hello_python.py
```

#### uv vs pip — Quick Reference

| Task | pip + venv | uv |
|---|---|---|
| Create environment | `python3 -m venv .venv` | `uv init` (automatic) |
| Activate environment | `source .venv/bin/activate` | `uv run ...` (no activation needed) |
| Install package | `pip install openai` | `uv add openai` |
| Install from file | `pip install -r requirements.txt` | `uv sync` |
| Lockfile | `pip freeze > requirements.txt` (approximate) | `uv.lock` (exact, automatic) |
| Speed | Baseline | 10–100× faster |
| Python version mgmt | Requires `pyenv` separately | Built in: `uv python install 3.12` |

#### pyproject.toml — the uv project file

When you run `uv init`, it creates `pyproject.toml`. This is the modern Python equivalent of `pom.xml`:

```toml
[project]
name = "ai-starter"
version = "0.1.0"
description = "LLM Tutorial — Enterprise AI with LangGraph"
requires-python = ">=3.12"
dependencies = [
    "openai>=1.0.0",
    "python-dotenv>=1.0.0",
    "langchain>=0.3.0",
    "langgraph>=0.2.0",
]

[tool.uv]
dev-dependencies = [
    "pytest>=8.0.0",
    "ruff>=0.5.0",
]
```

> **For this tutorial:** all `Try it out` sections show commands using `uv run`. If your environment does not have `uv`, the `python` equivalent is always noted.

---

### Project Structure

A Python LLM project follows a simple, flat convention:

```
ai-starter/
├── .venv/                  # virtual environment — never commit this
├── .env                    # environment variables (API keys) — never commit this
├── requirements.txt        # dependency list ≈ pom.xml
├── scripts/                # runnable Python scripts (our tutorial code lives here)
│   ├── 00_hello_python.py
│   ├── 01_raw_llm.py
│   └── ...
└── docs/
    └── modules/            # you are here
```

---

## 0.3 — Python Syntax: The Java Translation Table

### Variables and Types

```java
// Java — explicit types, required
String name = "Alice";
int age = 30;
boolean isActive = true;
```

```python
# Python — types inferred, type hints optional but recommended
name: str = "Alice"
age: int = 30
is_active: bool = True
```

> Python uses `snake_case` for variables and functions. Java uses `camelCase`. This is the most frequent muscle-memory mistake — it fades quickly.

---

### Functions

```java
// Java
public String greet(String name, int age) {
    return "Hello " + name + ", age " + age;
}
```

```python
# Python — no access modifiers, return type is a hint not enforced
def greet(name: str, age: int) -> str:
    return f"Hello {name}, age {age}"    # f-strings ≈ String.format()
```

---

### Classes

```java
// Java
public class BankAccount {
    private String owner;
    private double balance;

    public BankAccount(String owner, double balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public double getBalance() {
        return this.balance;
    }
}
```

```python
# Python
class BankAccount:
    def __init__(self, owner: str, balance: float):
        self.owner = owner          # no 'private' — convention: _owner means internal
        self.balance = balance

    def get_balance(self) -> float:
        return self.balance
```

> **Key difference:** `self` is the explicit `this`. Python does not infer it — every instance method must accept `self` as its first parameter.

---

### Dataclass ≈ Java Record

```java
// Java Record (Java 16+)
record Transaction(String id, double amount, String currency) {}
```

```python
# Python dataclass — same idea
from dataclasses import dataclass

@dataclass
class Transaction:
    id: str
    amount: float
    currency: str

# Usage
tx = Transaction(id="TX001", amount=1500.0, currency="EUR")
print(tx.amount)    # 1500.0
```

---

### Interfaces → Protocol

```java
// Java Interface
public interface Analyser {
    String analyse(String document);
}
```

```python
# Python Protocol (structural typing — duck typing with hints)
from typing import Protocol

class Analyser(Protocol):
    def analyse(self, document: str) -> str:
        ...
```

---

### Collections

```java
// Java
List<String> items = new ArrayList<>(List.of("a", "b", "c"));
Map<String, Integer> scores = new HashMap<>(Map.of("alice", 95));
```

```python
# Python
items: list[str] = ["a", "b", "c"]
scores: dict[str, int] = {"alice": 95}

# Access
print(scores["alice"])        # 95
print(scores.get("bob", 0))   # 0 — safe get with default, ≈ getOrDefault()
```

---

### Exception Handling

```java
// Java
try {
    int result = riskyOperation();
} catch (IOException e) {
    System.err.println("Failed: " + e.getMessage());
} finally {
    cleanup();
}
```

```python
# Python
try:
    result = risky_operation()
except IOError as e:
    print(f"Failed: {e}")
finally:
    cleanup()
```

---

### Lambda / Functional Style

```java
// Java
List<String> upper = items.stream()
    .filter(s -> s.startsWith("a"))
    .map(String::toUpperCase)
    .collect(Collectors.toList());
```

```python
# Python — list comprehension (idiomatic) or map/filter
upper = [s.upper() for s in items if s.startswith("a")]

# Or with map/filter (less common in Python)
upper = list(map(str.upper, filter(lambda s: s.startswith("a"), items)))
```

---

## 0.4 — The dict and TypedDict — The Workhorse of LLM Frameworks

This is the single most important data structure to understand before touching LangChain or LangGraph.

### Plain dict

```python
# A dict is just a key-value store — like a Java HashMap
message = {
    "role": "user",
    "content": "Summarise this document"
}

print(message["role"])     # "user"
print(message.get("id"))   # None — no KeyError
```

### TypedDict ≈ Java Record with named fields and types

LangGraph's state is always a `TypedDict`. Think of it as a strongly typed DTO that flows through your workflow.

```python
from typing import TypedDict

class WorkflowState(TypedDict):
    document_text: str
    risk_score: float
    analyst_notes: str
    approved: bool

# Usage — LangGraph passes this between every node
state: WorkflowState = {
    "document_text": "Client financials Q1 2026...",
    "risk_score": 0.0,
    "analyst_notes": "",
    "approved": False
}
```

> **Why not a dataclass?** `TypedDict` serialises to a plain `dict` automatically, which is what LangGraph expects for state passing. Dataclasses require extra steps. You will use `TypedDict` constantly — get comfortable with it now.

---

## 0.5 — Type Hints and Why They Matter Here

Python does not enforce types at runtime (unlike Java), but type hints:

- Make your code readable and self-documenting
- Enable IDE autocomplete and error detection
- Are **required** by LangGraph for state definitions
- Are used by Pydantic to validate LLM outputs

```python
from typing import Optional, List, Union

def process_document(
    text: str,
    max_length: Optional[int] = None,
    tags: List[str] = []
) -> dict[str, Union[str, int]]:
    ...
```

---

## 0.6 — Environment Variables for Secrets

Never hardcode API keys. Use environment variables — same principle as Spring's `application.properties` with externalized config.

```bash
# Create a .env file at project root (add to .gitignore immediately)
OPENAI_API_KEY=sk-...
DBLLM_EMAIL=your.email@db.com
DBLLM_API_KEY=your-api-key
DBLLM_KANNON_ID=your-kannon-id
```

```python
# Load in your script using python-dotenv
from dotenv import load_dotenv
import os

load_dotenv()   # reads .env file into os.environ

api_key = os.getenv("OPENAI_API_KEY")
email   = os.getenv("DBLLM_EMAIL")
```

```bash
# Install the dotenv loader
pip install python-dotenv
```

---

## 0.7 — Running Scripts

```bash
# Always activate venv first
source .venv/bin/activate

# Run a script
python scripts/00_hello_python.py

# Run interactively (REPL — great for exploration, like jshell)
python
>>> 2 + 2
4
>>> exit()

# Install all dependencies at once
pip install -r requirements.txt
```

---

## 0.8 — Try It Out

### Setup

```bash
# Option A — using uv (recommended)
uv init ai-starter
cd ai-starter
uv add python-dotenv

# Option B — using pip + venv (fallback)
python3 -m venv .venv
source .venv/bin/activate
pip install python-dotenv
```

Create `.env` in the project root:

```
DBLLM_EMAIL=your.email@db.com
DBLLM_API_KEY=your-api-key
DBLLM_KANNON_ID=your-kannon-id
```

### Script: `scripts/00_hello_python.py`

```python
"""
M0 — Hello Python
Demonstrates: variables, functions, dataclass, TypedDict, env vars
"""

import os
from dataclasses import dataclass
from typing import TypedDict
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# --- 1. Basic variables and f-string ---
name: str = "System Architect"
language: str = "Python"
print(f"Hello, {name}. Welcome to {language}.")

# --- 2. Function with type hints ---
def calculate_risk_score(exposure: float, probability: float) -> float:
    """Simple expected loss formula — maps to EL = EAD x PD in credit risk."""
    return round(exposure * probability, 4)

score = calculate_risk_score(exposure=1_000_000.0, probability=0.03)
print(f"Expected Loss: EUR {score:,.2f}")

# --- 3. Dataclass (Java Record equivalent) ---
@dataclass
class Transaction:
    id: str
    amount: float
    currency: str
    flagged: bool = False

tx = Transaction(id="TX-9921", amount=2_500_000.0, currency="EUR")
print(f"Transaction: {tx}")

# --- 4. TypedDict (LangGraph state preview) ---
class WorkflowState(TypedDict):
    document_text: str
    risk_score: float
    approved: bool

state: WorkflowState = {
    "document_text": "Client Q1 financials: revenue EUR 50M, debt EUR 120M",
    "risk_score": 0.0,
    "approved": False
}
print(f"Initial state: {state}")

# --- 5. Environment variables ---
email = os.getenv("DBLLM_EMAIL", "NOT SET")
print(f"DB LLM will use email: {email}")
```

### Expected Output

```
Hello, System Architect. Welcome to Python.
Expected Loss: EUR 30,000.00
Transaction: Transaction(id='TX-9921', amount=2500000.0, currency='EUR', flagged=False)
Initial state: {'document_text': 'Client Q1 financials: revenue EUR 50M, debt EUR 120M', 'risk_score': 0.0, 'approved': False}
DB LLM will use email: your.email@db.com
```

### Run it

```bash
# uv (recommended — no activation needed)
uv run python scripts/00_hello_python.py

# pip + venv (alternative)
source .venv/bin/activate
python scripts/00_hello_python.py
```

---

## 0.9 — Module Summary

| Concept | Java | Python |
|---|---|---|
| Project isolation | Maven module / Gradle | `venv` or `uv` (recommended) |
| Dependency declaration | `pom.xml` | `pyproject.toml` (uv) / `requirements.txt` (pip) |
| Dependency install | `mvn install` | `uv sync` / `pip install -r requirements.txt` |
| Add a dependency | Edit `pom.xml` + `mvn install` | `uv add <package>` |
| Run a script | `java -cp ... Main` | `uv run python script.py` |
| Typed data container | POJO / Java Record | `dataclass` / `TypedDict` |
| Interface / contract | `interface` | `Protocol` |
| Null-safe map access | `map.getOrDefault(k, v)` | `dict.get(k, v)` |
| String interpolation | `String.format()` | f-string `f"..."` |
| Secret configuration | `application.properties` | `.env` + `os.getenv()` |
| Entry point | `public static void main` | top-level script or `if __name__ == "__main__":` |

---

## 0.10 — What's Next

You now have the Python vocabulary to read and write code confidently. In **Module 1**, we go straight to the first real task: calling an LLM API. No framework yet — just Python and an HTTP endpoint. You will see exactly what happens under the hood, and you will call both the standard OpenAI/Gemini SDK and the Deutsche Bank internal LLM wrapper using the same pattern.

> **Proceed to:** `M1_raw_llm_interactions.md`

---

*Module 0 of 11 · From Java to LLMs: A System Architect's Guide*
