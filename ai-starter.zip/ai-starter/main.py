def main():
    print("Hello from ai-starter!")


if __name__ == "__main__":
    main()
